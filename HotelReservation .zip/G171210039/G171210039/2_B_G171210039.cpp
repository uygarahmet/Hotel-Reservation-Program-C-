/****************************************************************************
**							 SAKARYA �N�VERS�TES�
**			         B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
**						 B�LG�SAYAR M�HEND�SL��� B�L�M�
**						 NESNEYE DAYALI PROGRAMLAMA DERS�
**							2017-2018 G�Z D�NEM�
**					 �DEV NUMARASI....: Proje �devi
**				     ��RENC� ADI......: Uygar Ahmet Sapmaz
**					 ��RENC� NUMARASI.: G171210039
**					 DERS GRUBU.......: B Grubu
**
****************************************************************************/
#include<iostream>		//K�t�phaneler 
#include <fstream>
#include<string>
#include <stdio.h>
int secim = 0;
char devam = 'e';
using namespace std;
class Otel		//Burada otel i�in kullanacak oldu�um s�n�f� a�t�m.
{
private:		//De�i�kenleri private olarak tan�mlad�m sadece s�n�f�n i�inden eri�ebilsin diye.
	string ad;
	string soyad;
	string tc;
	string no;
	string oda;
	string odafiyat;
public:
	int musteriekle(void)
	{
		int syc = 0;
		int var = 0;
		string musno;
		ofstream dosyaYaz;
		char devam = 'e';
		dosyaYaz.open("M��teriBilgileri.txt", ios::app); //Dosyaya yazmak i�in dosyay� a�t�m.
		int i = 0;
		do
		{
			var = 1;
			syc = 0;
			ifstream dosyaOku1;
			dosyaOku1.open("M��teriBilgileri.txt"); //Dosyay� okumak i�in a�t�m.
			cout << "M��teri Numaras�n� giriniz= ";
			cin >> musno;
			while (!dosyaOku1.eof())
			{
				dosyaOku1 >> no;
				if (musno == no) syc++; // Ayn� m��teriden var m� diye kontrol ettirdim.
			}
			if (syc == 0)
			{
			}
			else {
				cout << "B�yle bir m��teri zaten vard�r." << endl;
				var = 0;
			}
			if (var == 1) //Ayn� m��teriden yoksa verileri almaya devam ettim.
			{
				cout << "M�steri ad�n� giriniz = ";
				cin >> ad;
				for (i = 0; i < (ad.length()); i++) //0'dan ad�n karakter say�s�na kadar d�ng� kurdum.
				{
					if ((ad[i] > 47) && (ad[i] < 58)) // Ad�n i�inde rakam var m� diye kontrol ettirdim.
					{
						cout << "Hatal� karakter girdiniz tekrar giriniz \n";
						cin >> ad;
						i = 0;
					}
				}
				cout << "M�steri soyad�n� giriniz = ";
				cin >> soyad;
				for (i = 0; i < (soyad.length()); i++) //0'dan soyad�n karakter say�s�na kadar d�ng� kurdum.
				{
					if ((soyad[i] > 47) && (soyad[i] < 58)) // Soyad�n i�inde rakam var m� diye kontrol ettirdim.
					{
						cout << "Hatal� karakter girdiniz tekrar giriniz \n";
						cin >> soyad;
						i = 0;
					}
				}
				do {
					cout << "M�steri TC kimlik numaras�n� giriniz = ";
					cin >> tc;
					for (int i = 0; i < (tc.length()); i++) //0'dan TC'nin karakter say�s�na kadar d�ng� kurdum.
					{
						if (((tc[i] > 64) && (tc[i] < 91)) || ((tc[i] > 96) && (tc[i] < 123))) //TC'nin i�inde harf var m� diye kontrol ettirdim.
						{
							cout << "Hatal� karakter girdiniz tekrar giriniz ";
							cin >> tc;
							i = 0;
						}
					}
					if (tc.length() != 11) //TC'nin 11 karaktere e�it olup olmad���n� kontrol ettirdim.
					{
						cout << "Eksik veya fazla karakter girdiniz tekrar giriniz ";
					}
				} while (!(tc.length() == 11)); //TC 11 karaktere e�it olmad��� s�rece d�ng�den ��kmamas�n� sa�lad�m.
				dosyaYaz << endl << musno << "  " << ad << "  " << soyad << "  " << tc; //Girdi�im verileri M��teriBilgileri.txt dosyas�na yazd�rd�m.
			}
			cout << "Yeni kay�t yapacak m�s�n�z (e/h)";
			cin >> devam;
			if (devam == 'h') //Girilen cevap h'ye e�itse d�ng�den ��kard�m.
			{
				secim = 99;
			}
			system("cls");
		} while (devam != 'h');
		dosyaYaz.close(); //Yazmak i�in a�t���m dosyay� kapatt�m.
		return secim;
	}
	int musterilistele(void)
	{
		ifstream dosyaOku; //Dosyay� okumak i�in a�t�m.
		dosyaOku.open("M��teriBilgileri.txt");
		while (!dosyaOku.eof()) //Dosyan�n i�indekiler bitene kadar okuyor.
		{
			dosyaOku >> no >> ad >> soyad >> tc; //Dosyadan verileri okuttum.
			cout << "M��teri Numaras�: " << no << " M��teri Ad�: " << ad << " M��teri Soyad�: " << soyad << " M��teri TC: " << tc << endl; //Bu verileri ekrana yazd�rd�m.
		}
		cout << "\n" << "�st men�ye d�nmek i�in 99'u tu�lay�n";
		cin >> secim;
		system("cls");
		dosyaOku.close();
		return secim;
	}
	int odaekle(void)
	{
		int syc = 0;
		int var = 0;
		string odanumara;
		string odaprice;
		ofstream dosyaYaz;
		dosyaYaz.open("OdaBilgileri.txt", ios::app); //Dosyaya yazmak i�in dosyay� a�t�m.
		do
		{
			syc = 0;
			var = 1;
			ifstream dosyaOku1; //Dosyay� okumak i�in a�t�m.
			dosyaOku1.open("OdaBilgileri.txt");
			cout << "Oda Numaras�n� giriniz = ";
			cin >> odanumara;
			while (!dosyaOku1.eof()) //Dosyan�n i�indekiler bitene kadar okuyor.
			{
				dosyaOku1 >> oda;
				if (odanumara == oda) syc++; // Ayn� odadan var m� diye kontrol ettirdim.
			}
			if (syc == 0)
			{
			}
			else
			{
				cout << "B�yle bir oda zaten vard�r.";
				var = 0;
			}
			if (var == 1)  //Ayn� odadan yoksa verileri almaya devam ettim.
			{
				cout << "Oda fiyat�n� giriniz = ";
				cin >> odaprice;
				dosyaYaz << endl << odanumara << "  " << odaprice << "  "; //Girdi�im verileri OdaBilgileri.txt dosyas�na yazd�rd�m.
			}
			cout << "Yeni kay�t yapacak m�s�n�z (e/h)";
			cin >> devam;
			if (devam == 'h') //Girilen cevap h'ye e�itse d�ng�den ��kard�m.
			{
				secim = 99;
			}
			system("cls");
		} while (!(devam == 'h'));
		dosyaYaz.close(); //Yazmak i�in a�m�� oldu�um dosyay� kapatt�m.
		return secim;
	}
	int odalistele(void)
	{
		int a = 0;
		string deger;
		ifstream dosyaOku;
		dosyaOku.open("OdaBilgileri.txt"); //Dosyay� okumak i�in a�t�m.
		while (!dosyaOku.eof())
		{
			if (0<a) deger = oda; // Burada odalar� listelerken son oday� ekrana iki kere bas�yordu bunu engellemek i�in d�ng� kurdum.
			dosyaOku >> oda >> odafiyat; //Dosyadan verileri okuttum.
			if (a == 0)cout << "Oda Numaras�: " << oda << " Oda Fiyat�: " << odafiyat << endl;
			else
			{
				if (deger == oda)
				{
				}
				else cout << "Oda Numaras�: " << oda << " Oda Fiyat�: " << odafiyat << endl;
			}
			a++;
		}
		cout << "\n" << "�st men�ye d�nmek i�in 99'u tu�lay�n ";
		cin >> secim;
		system("cls");
		dosyaOku.close(); //Okumak i�in a�tt���m dosyay� kapatt�m.
		return secim;
	}
	int odakayit(void)
	{
		string gecicioda; //Kaydetmek istedi�im oda ve m��terileri aramak i�in ge�ici de�erler kulland�m.
		string gecicimusteri;
		char devam = 'e';
		ifstream dosyaOku; // dosyaOku'yu okumak i�in a�t�m.
		ifstream dosyaOku1; // dosyaOku1'i okumak i�in a�t�m.
		ifstream dosyaOku2; // dosyaOku2'yi okumak i�in a�t�m.
		ofstream dosyaYaz; // Dosyay� yazmak i�in a�t�m.
		do
		{
			dosyaOku.open("OdaBilgileri.txt");
			dosyaYaz.open("OdaKay�t.txt", ios::app);
			cout << "Oda Numaras�n� giriniz = ";
			cin >> gecicioda;
			while (!dosyaOku.eof())
			{
				dosyaOku >> oda;
				if (oda == gecicioda) //Arad���m oday� dosyadan bulup ekrana yazd�rd�m.
				{
					dosyaYaz << endl << oda << "  ";
					cout << "Oda numaras�: " << oda << endl;
				}
			}
			dosyaYaz.close(); // Yazmak i�in a�t���m dosyay� kapatt�m.
			dosyaOku.close(); // dosyaOku'yu kapatt�m.
			cout << "M��teri Numaras�n� giriniz = ";
			cin >> gecicimusteri;
			dosyaOku1.open("M��teriBilgileri.txt");
			dosyaYaz.open("OdaKay�t.txt", ios::app);
			while (!dosyaOku1.eof())
			{
				dosyaOku1 >> no >> ad >> soyad >> tc;
				if (gecicimusteri == no) //Arad���m m��teriyi dosyadan bulup ekrana yazd�rd�m.
				{
					dosyaYaz << ad << "  " << soyad << "  " << tc << "  " << no;
					cout << "M��teri ad�: " << ad << " M��teri soyad�: " << soyad << " M��teri Tc: " << tc << " M��teri no: " << no << endl;
				}
			}
			dosyaOku1.close();
			dosyaYaz.close();
			dosyaOku2.open("OdaKay�t.txt", ios::app);
			while (!dosyaOku2.eof()) //Odalara kaydetti�im m��terileri ekranda listeledim.
			{
				dosyaOku2 >> oda >> ad >> soyad >> tc >> no;
				cout << "Oda numaras�: " << oda;
				cout << " M��teri ad�: " << ad << " M��teri soyad�: " << soyad << " M��teri Tc: " << tc << " M��teri no: " << no << endl;
			}
			dosyaOku2.close();
			cout << "Yeni ekleme  yapacak m�s�n�z (e/h)";
			cin >> devam;
			if (devam == 'h')
			{
				secim = 99;
			}
			system("cls");
		} while (devam != 'h');
		return secim;
	}
	int musterisil(void)
	{
		string musno;
		ifstream dosyaOku("M��teriBilgileri.txt");
		ofstream dosyaYaz("M��teriBilgileri.tmp"); //Yedek dosyay� a�t�m.
		cout << "Silmek istedi�iniz m��teri numaras�n� giriniz = ";
		cin >> musno;
		while (!dosyaOku.eof())
		{
			dosyaOku >> no >> ad >> soyad >> tc;
			if (musno == no) //Silmek istedi�im m��teriyi ekrana yazd�rd�m.
			{
				cout << "M��teri Numaras�: " << no << " M��teri Ad�: " << ad << " M��teri Soyad�: " << soyad << " M��teri TC: " << tc << endl;
			}
			else // Kalan m��terileri tekrar dosyaya yazd�rd�m.
			{
				dosyaYaz << endl << no << "  " << ad << "  " << soyad << "  " << tc;
			}
		}
		cout << "Yeni silme yapacak m�s�n�z (e/h)";
		cin >> devam;
		if (devam == 'h')
		{
			secim = 99;
		}
		system("cls");
		dosyaYaz.close();
		dosyaOku.close();
		remove("M��teriBilgileri.txt"); //As�l veri dosyas�n� sildirdim.
		rename("M��teriBilgileri.tmp", "M��teriBilgileri.txt"); //Yedek dosyan�n ismini as�l dosya ile de�i�tirdim.
		return secim;
	}
	int odasil(void)
	{
		string noda;
		ifstream dosyaOku("OdaBilgileri.txt");
		ofstream dosyaYaz("OdaBilgileri.tmp"); //Yedek dosyay� a�t�m.
		cout << "Silmek istedi�iniz oda numaras�n� giriniz = ";
		cin >> noda;
		while (!dosyaOku.eof())
		{
			dosyaOku >> oda >> odafiyat;
			if (noda == oda) //Silmek istedi�im oday� ekrana yazd�rd�m.
			{
				cout << "Oda Numaras�: " << oda << " Oda Fiyat�: " << odafiyat << endl;
			}
			else // Kalan odalar� tekrar dosyaya yazd�rd�m.
			{
				dosyaYaz << endl << oda << "  " << odafiyat;
			}
		}
		cout << "Yeni silme yapacak m�s�n�z (e/h)";
		cin >> devam;
		if (devam == 'h')
		{
			secim = 99;
		}
		dosyaYaz.close();
		dosyaOku.close();
		remove("OdaBilgileri.txt"); //As�l veri dosyas�n� sildirdim.
		rename("OdaBilgileri.tmp", "OdaBilgileri.txt"); //Yedek dosyan�n ismini as�l dosya ile de�i�tirdim.
		return secim;
	}
	int odakayitsil(void)
	{
		char devam = 'e';
		string noda;
		ifstream dosyaOku("OdaKay�t.txt");
		ofstream dosyaYaz("OdaKay�t.tmp"); //Yedek dosyay� a�t�m.
		cout << "Silmek istedi�iniz oda numaras�n� giriniz = ";
		cin >> noda;
		while (!dosyaOku.eof())
		{
			dosyaOku >> oda >> ad >> soyad >> tc >> no;
			if (noda == oda) //Silmek istedi�im oday� ve o odadaki m��teriyi ekrana yazd�rd�m.
			{
				cout << "Oda Numaras�: " << oda << " M��teri Ad�: " << ad << " M��teri Soyad�: " << soyad << " M��teri TC: " << tc << "M��teri Numaras�: " << no << endl;
			}
			else // Kalan odalar� ve o odadaki m��terileri tekrar dosyaya yazd�rd�m.
			{
				dosyaYaz << endl << oda << "  " << ad << "  " << soyad << "  " << tc << "  " << no;
			}
		}
		cout << "Yeni ekleme  yapacak m�s�n�z (e/h)";
		cin >> devam;
		if (devam == 'h')
		{
			secim = 99;
		}
		dosyaYaz.close();
		dosyaOku.close();
		remove("OdaKay�t.txt"); //As�l veri dosyas�n� sildirdim.
		rename("OdaKay�t.tmp", "OdaKay�t.txt"); //Yedek dosyan�n ismini as�l dosya ile de�i�tirdim.
		return secim;
	}
};
int main()
{
	setlocale(LC_ALL, "TURKISH"); //T�rk�e karakterler i�in
	int secim;
	Otel mus; // Class s�n�f�ndan nesne olu�turdum.
	int dondur;
	do
	{
		cout << "Otel ��lemleri \n";			//	MEN�
		cout << "---------------- \n";
		cout << "1-Oda ��lemleri \n";
		cout << "2-M��teri ��lemleri \n";
		cout << "3-Oda Kay�t ��lemleri \n";
		cout << "99-��k�� \n";
		cout << "Se�iminiz  :";
		cin >> secim;
		system("cls");
		if (secim == 1)
		{
			cout << "Oda ��lemleri \n";
			cout << "---------------- \n";
			cout << "1-Oda Ekle \n";
			cout << "2-Oda Sil \n";
			cout << "3-Odalar� Listele \n";
			cout << "99-�st Men� \n";
			cout << "Se�iminiz  :";
			cin >> secim;
			dondur = secim;
			system("cls");
			do
			{
				if (secim == 1)
				{
					dondur = mus.odaekle(); //Oda ekleme fonksiyonunu �a��rd�m.
				}
				else if (secim == 2)
				{
					dondur = mus.odasil();	//Oda silme fonksiyonunu �a��rd�m.
				}
				else if (secim == 3)
				{
					dondur = mus.odalistele();	//Oda listele fonksiyonunu �a��rd�m.
				}
				else if (secim == 99)
				{
					break;
				}
				else
				{
					cout << "Hatal� Se�im \n";
				}
			} while (dondur != 99);
		}
		else if (secim == 2)
		{
			cout << "M��teri ��lemleri \n";			//		MEN�
			cout << "---------------- \n";
			cout << "1-M��teri Ekle \n";
			cout << "2-M��teri Sil \n";
			cout << "3-M��terileri Listele \n";
			cout << "99-�st Men� \n";
			cout << "Se�iminiz  :";
			cin >> secim;
			system("cls");
			do
			{
				if (secim == 1)
				{
					dondur = mus.musteriekle();	//M��teri ekleme fonksiyonunu �a��rd�m.
				}
				else if (secim == 2)
				{
					dondur = mus.musterisil();	//M��teri silme fonksiyonunu �a��rd�m.
				}
				else if (secim == 3)
				{
					dondur = mus.musterilistele();	//M��teri listele fonksiyonunu �a��rd�m.
				}
				else if (secim == 99)
				{
					break;
				}
				else
				{
					cout << "Hatal� Se�im \n";
				}
			} while (dondur != 99);
		}
		else if (secim == 3)
		{
			cout << "1-Oda Kay�t ��lemi" << endl;			//		MEN�
			cout << "2-Oda Kay�t Silme" << endl;
			cout << "3-��k��" << endl;
			cin >> secim;
			switch (secim)
			{
			case 1:
				dondur = mus.odakayit();	//Oda kay�t fonksiyonunu �a��rd�m.
				break;
			case 2:
				dondur = mus.odakayitsil();	 //// Odadan kay�t silme fonksiyonunu �a��rd�m.
				break;
			case 3:
				dondur = 99;
				break;
			}
		}
		else if (secim == 99)
		{
			break;
		}
		else
		{
			cout << "Hatal� Se�im \n";
		}
	} while (dondur == 99);
	system("pause");
	return 0;
}
